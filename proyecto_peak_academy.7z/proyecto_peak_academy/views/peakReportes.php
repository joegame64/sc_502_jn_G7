<?php include '../core/header.php'; ?>
<?php include '../includes/helpers.php'; ?>

<!-- Pequeño anuncio -->
<br>
<center><h5 class="anuncio text-center">Reportes</h5>
<br>
<p class="anuncio text-center mt-4">Escoge un curso para ver el reporte de estudiantes matriculados</p></center>
<hr>

<?php
// Incluir la conexión a la base de datos
include('../includes/conexion.php');

// Consultar los cursos
$sql = "SELECT * FROM cursos";
$result = $conn->query($sql);


// Verificar si se encontraron resultados
if ($result && $result->num_rows > 0) {
 
    echo '<div class="container-custom"><div class="row-custom row row-cols-1 row-cols-md-3 g-4">';
   

    // Iterar sobre los resultados y generar las tarjetas
    while ($row = $result->fetch_assoc()) {
        $nombreArchivo = limpiarNombreArchivo($row['nombre']); // Limpiar el nombre

        echo '<div class="card">
                <div class="card-body">
                    <h5 class="card-title text-center">' . htmlspecialchars($row['nombre']) . '</h5>
                    <p class="card-text">' . htmlspecialchars($row['descripcion']) . '</p>
                    <hr>
                    <p>' . (isset($row['horarios']) ? htmlspecialchars($row['horarios']) : 'Horario no especificado') . '</p>
                    <hr>
                    <p>' . (isset($row['ubicacion']) ? htmlspecialchars($row['ubicacion']) : 'Ubicación no especificada') . '</p>
                    <div class="d-flex justify-content-center">
                        <a href="../views/peak' . $nombreArchivo . '.php" class="btn btn-primary">Ir a Notas</a>
                    </div>
                </div>
              </div>';
    }

    echo '</div></div>';
} else {
    echo "<p class='anuncio text-center'>No se encontraron cursos.</p>";
}

// Cerrar la conexión
$conn->close();
?>

<!-- Footer de la página -->
<?php include '../core/footer.php'; ?>
