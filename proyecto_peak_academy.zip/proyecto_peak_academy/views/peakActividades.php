<?php include '../core/header.php'; ?>

<h5 class="anuncio">Prácticas para los estudiantes</h5>
<hr>



    <p class="anuncio" style="margin-top: 25px;">Actividades</p>
    <!--Cards de las notas -->
    <div class="container-custom">
        <div class="row-custom">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Tour con clase de Ambiente Web</h5>
                    <p class="card-text">15 Estudites</p>
                    <hr>
                    <p>Lunes 13 Abril 10 AM- 3 PM</p>
                    <hr>
                    <p>IBM</p>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Merienda Compartida con Bases de Datos</h5>
                    <p class="card-text">15 Estudites</p>
                    <hr>
                    <p>Martes 2-5 PM</p>
                    <hr>
                    <p>Sede Heredia</p>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Jira con Estructura de Datos</h5>
                    <p class="card-text">30 Estudites</p>
                    <hr>
                    <p>Jueves 21 Agosto 8 AM - 12 PM</p>
                    <hr>
                    <p>Amazon</p>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Charela con Programacion Basica</h5>
                    <p class="card-text">35 Estudites</p>
                    <hr>
                    <p>Lunes 8-11 AM</p>
                    <hr>
                    <p>Auditorio de Heredia </p>
                </div>
            </div>
        </div>
    </div>

    <!--footer de la pagina -->
<?php include '../core/footer.php'; ?>
